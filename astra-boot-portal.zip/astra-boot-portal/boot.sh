#!/usr/bin/env bash
# Astra Boot Portal — QEMU TCG + serial console, served in browser via ttyd
# Quick path: see AstraOS ISO boot in your Codespaces browser.
set -e

# ── Config (override via env vars or first CLI arg) ──
ASTRA_ISO="${ASTRA_ISO:-./astraos.iso}"
ASTRA_PORT="${ASTRA_PORT:-7681}"
ASTRA_RAM="${ASTRA_RAM:-4096}"
ASTRA_SMP="${ASTRA_SMP:-2}"
ASTRA_CPU="${ASTRA_CPU:-max}"

# First CLI arg overrides ISO path
if [ -n "$1" ]; then
  ASTRA_ISO="$1"
fi

cat <<'BANNER'
===================================================
   ___         __          ___         __          ___
  / _ | ___ _/_/____ ___  / _ | ___ _/_/____ ___  / _ | ___ ___
 / __ |/ _ `/ / __// _ \/ __ |/ _ `/ / __// -_)/ __ |/ -_(_-<
/_/ |_|\_,_/_/\__//_//_/_/ |_|\_,_/_/\__//_//_/_/ |_|\__/___/

   AstraOS — BOOT PORTAL
   See AstraOS ISO boot in your browser (serial console)
   QEMU TCG (no KVM on Codespaces) — boot slow (~3-5 min). Be patient.
===================================================
BANNER

echo "ISO path : $ASTRA_ISO"
echo "RAM      : ${ASTRA_RAM} MB"
echo "CPUs     : ${ASTRA_SMP}"
echo "Web port : $ASTRA_PORT (Codespaces auto-forwards)"
echo ""

# ── Pre-flight checks ──
if [ ! -f "$ASTRA_ISO" ]; then
  echo "X  ISO not found at: $ASTRA_ISO"
  echo "   -> Place a file named 'astraos.iso' in this folder,"
  echo "   -> OR:  export ASTRA_ISO=/absolute/path/to/your.iso"
  echo "   -> OR:  bash boot.sh /path/to/your.iso"
  exit 1
fi

for cmd in qemu-system-x86_64 ttyd; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "X  $cmd not installed. Run: bash install.sh"
    exit 1
  fi
done

echo "OK  Pre-flight passed."
echo "-> Open the forwarded port $ASTRA_PORT in your browser (Codespaces notifies you)."
echo "-> Exit: Ctrl+C in this terminal, or close the ttyd browser tab."
echo ""

# ── Launch ttyd wrapping QEMU ──
# ttyd serves QEMU's serial console (stdio) in the browser.
# -W = writable (let browser send input to login prompt)
# -nographic = QEMU serial + monitor -> stdio (no graphical display needed)
# -no-reboot = VM exits instead of rebooting (clean ttyd close)
exec ttyd \
  -p "$ASTRA_PORT" \
  -W \
  -- \
  qemu-system-x86_64 \
    -accel tcg \
    -cpu "$ASTRA_CPU" \
    -smp "$ASTRA_SMP" \
    -m "$ASTRA_RAM" \
    -cdrom "$ASTRA_ISO" \
    -nographic \
    -no-reboot
