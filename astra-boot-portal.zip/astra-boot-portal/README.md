# Astra Boot Portal

> See **AstraOS ISO 4** boot in your browser — no QEMU install on your local PC, no display needed on Codespaces.
> Quick path: `ttyd` wraps QEMU's serial console and serves it in the browser via Codespaces port forwarding.

## Why this exists

Naoum's constraint: school PC has QEMU blocked, no BIOS access, no home PC, Codespaces has no graphical display.
So we run QEMU on Codespaces (where it installs fine) and bridge its **serial console** to the browser via `ttyd`. You see the boot logs + login prompt + can interact, all in your school PC browser.

> QEMU TCG (software emulation, no KVM on Codespaces) = boot slow (~3-5 min) but it boots. You won't see the Hyprland GUI this way — you'll see the **serial TTY** (boot logs + login). That's enough to verify the ISO works and explore the booted OS in CLI.

---

## Setup on Codespaces (5 steps)

### 1. Create a clean Codespace
From your AstraOS-Beta repo on GitHub → `Code` → `Codespaces` → `Create new codespace` (or recreate a clean one).

### 2. Get this folder into the Codespace
Copy these 3 files into the Codespace (e.g. in `~/astra-boot-portal/`):
- `install.sh`
- `boot.sh`
- `README.md` (this file)

(Easiest: drag-drop the folder into the Codespaces file explorer, or `git clone` a gist / a branch containing the folder.)

### 3. Install QEMU + ttyd
```bash
cd ~/astra-boot-portal
bash install.sh
```
This runs `sudo apt-get install qemu-system-x86 ttyd curl` (Codespaces = Ubuntu). ~1 min.

### 4. Put the AstraOS ISO 4 in the folder
Either:
- drop `astraos.iso` into `~/astra-boot-portal/` (default name), OR
- `export ASTRA_ISO=/path/to/astraos-iso4.iso`, OR
- pass it as arg: `bash boot.sh /path/to/astraos-iso4.iso`

### 5. Launch
```bash
bash boot.sh
```
Codespaces will detect port `7681` and pop a notification: **"Your application running on port 7681 is available"** → click **Open in browser**.

You should see a dark terminal with AstraOS boot logs scrolling. Wait ~3-5 min (TCG slow) → login prompt appears → log in → explore the booted AstraOS in CLI.

---

## ⚠️ Critical caveat: ISO must have serial console enabled

For you to see boot logs in the browser, **AstraOS ISO 4 must expose a serial console**:
- kernel cmdline includes `console=ttyS0,115200`
- systemd `serial-getty@ttyS0.service` is enabled (so a login prompt appears on ttyS0)

**Most archiso-based ISOs already have this enabled by default.** If you see boot logs scrolling in the browser → it's enabled, you're good.

If you see a **blank screen** (QEMU running but no output) → serial console is NOT enabled in the ISO. Fix:

### How to enable serial console in the AstraOS ISO build
The ISO is built from `astraos-iso4/iso/x86_64/` (archiso profile). Two edits:

**a) Kernel cmdline** — in `iso/x86_64/syslinux/` (BIOS boot) and `efiboot/` + `boot/` (UEFI), add `console=ttyS0,115200` to the kernel append line. Example syslinux entry:
```
APPEND initrd=initramfs-linux.img archisobasedir=arch archisolabel=ASTRAOS console=ttyS0,115200
```

**b) Enable serial getty** — in `iso/x86_64/airootfs/` (the future rootfs), create the systemd symlink:
```bash
mkdir -p airootfs/etc/systemd/system/getty.target.wants
ln -sf /usr/lib/systemd/system/serial-getty@.service \
   airootfs/etc/systemd/system/getty.target.wants/serial-getty@ttyS0.service
```
Also add `ttyS0` to `airootfs/etc/securetty` if present (for root login on serial).

Then rebuild the ISO: `make build-iso pack=core`. Re-run `bash boot.sh`.

---

## UEFI vs BIOS boot

`boot.sh` boots via QEMU's default **SeaBIOS** (BIOS boot). archiso supports both BIOS and UEFI, so BIOS boot should work for AstraOS ISO 4.

If for some reason the ISO only boots UEFI, you'll see "Booting from DVD/CD..." then nothing. Fix: add OVMF firmware to the QEMU command in `boot.sh`:
```bash
    -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE.fd \
    -drive if=pflash,format=raw,file=/tmp/OVMF_VARS.fd \
```
(and `cp /usr/share/OVMF/OVMF_VARS.fd /tmp/` first). Most likely you won't need this.

---

## Config (env vars)

Override defaults before `bash boot.sh`:

| Var | Default | What |
|---|---|---|
| `ASTRA_ISO` | `./astraos.iso` | Path to the ISO |
| `ASTRA_PORT` | `7681` | Browser port (Codespaces forwards) |
| `ASTRA_RAM` | `4096` | VM RAM in MB (Hyprland+GTK4 needs ≥2GB, 4 safe) |
| `ASTRA_SMP` | `2` | VM CPU count (TCG doesn't parallelize well, 2 fine) |
| `ASTRA_CPU` | `max` | QEMU CPU model (`max` = all TCG features) |

Example:
```bash
ASTRA_ISO=/workspaces/AstraOS-Beta/out/astraos-0.4.0-x86_64.iso ASTRA_RAM=6144 bash boot.sh
```

---

## Troubleshooting

| Symptom | Cause / Fix |
|---|---|
| Port 7681 not forwarded | Codespaces usually auto-forwards. Manual: Ports tab → "Forward a port" → 7681. |
| Blank terminal, QEMU running | Serial console not enabled in ISO (see caveat above). |
| "KVM not working" warning | Expected on Codespaces (no nested virt). Falls back to TCG. Ignore. |
| Boot takes >10 min | TCG is slow. Hyprland+GTK4 init is heavy. Be patient, or reduce `ASTRA_RAM` to 2048. |
| `ttyd: command not found` | Run `bash install.sh` first. |
| `qemu-system-x86_64: command not found` | Run `bash install.sh` first. |
| Boot loops/restarts | `boot.sh` uses `-no-reboot` so QEMU exits on reboot. Check ISO integrity. |
| Want to type at login | Make sure the browser tab has focus. ttyd `-W` (writable) is set. |

---

## Exit

- `Ctrl+C` in the Codespaces terminal where `boot.sh` runs, OR
- close the ttyd browser tab (QEMU keeps running until you Ctrl+C the terminal).

---

## What you'll see (honest expectation)

- ✅ Kernel boot logs scrolling (dmesg, systemd services starting)
- ✅ `[ OK ] Started Astra Update Daemon`, `[ OK ] Started Astra Shell`, etc.
- ✅ Login prompt: `astraos login: _`
- ✅ Log in, explore the filesystem in CLI (`ls`, `cat`, `systemctl status`, etc.)
- ❌ You will NOT see the Hyprland desktop GUI (that needs graphical display, not serial console)

This is **ISO validation + CLI exploration**, not GUI testing. For GUI testing, you need a PC with KVM (future, when you have a personal PC).

---

## Files

- `install.sh` — installs qemu-system-x86 + ttyd (apt/dnf/pacman auto-detect)
- `boot.sh` — launches ttyd wrapping QEMU (TCG, serial console, ISO as cdrom)
- `README.md` — this file

## Architecture

```
Codespaces (Ubuntu container, x86_64, no /dev/kvm)
  |
  |-- QEMU TCG (-accel tcg) boots AstraOS ISO 4
  |     '-serial mon:stdio via -nographic (boot logs + login on stdio)
  |
  |-- ttyd -p 7681 -W wraps QEMU
  |     serves QEMU's stdio (serial console) as a web terminal (xterm.js)
  |
  '-- Codespaces forwards port 7681
        |
        v
   Your school PC browser -> you see AstraOS booting for real, can log in
```

---

Made for Naoum, AstraOS ISO 4. GLM.
