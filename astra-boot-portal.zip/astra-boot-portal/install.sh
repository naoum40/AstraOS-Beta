#!/usr/bin/env bash
# Astra Boot Portal — install dependencies on Codespaces (or any Debian/Fedora/Arch Linux)
set -e

echo "=== Astra Boot Portal — installing deps ==="

if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y
  sudo apt-get install -y qemu-system-x86 ttyd curl
elif command -v dnf >/dev/null 2>&1; then
  sudo dnf install -y qemu-system-x86 ttyd
elif command -v pacman >/dev/null 2>&1; then
  sudo pacman -S --noconfirm qemu-system-x86 ttyd
else
  echo "✗ No supported package manager (apt/dnf/pacman)."
  echo "  Install manually: qemu-system-x86_64 + ttyd"
  exit 1
fi

echo ""
echo "=== Versions ==="
qemu-system-x86_64 --version | head -1
ttyd --version 2>&1 | head -1 || echo "ttyd: installed"
echo ""
echo "=== Done. Next steps: ==="
echo "1. Place AstraOS ISO 4 in this folder as 'astraos.iso'"
echo "   (or: export ASTRA_ISO=/absolute/path/to/astraos-iso4.iso)"
echo "2. Run: bash boot.sh"
echo "3. Codespaces forwards port 7681 -> 'Open in browser' -> see AstraOS boot"
